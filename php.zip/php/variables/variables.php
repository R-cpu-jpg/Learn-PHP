<?php

//echo "This is variables learning";
// Variables are containers for storing the information
// Starts with a $

$name = "Soni";

// Variables are case sensitive
$namE = "Ujju";

$age = 25;

echo "$name's age is $age <br>";

echo "$namE is good girl";

?>